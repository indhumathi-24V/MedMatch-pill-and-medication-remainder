// Email,time
var Medicine = require('../models/medicine'),
    User     = require('../models/user');

