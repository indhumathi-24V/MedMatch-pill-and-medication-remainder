# MediLona

![alt text](./Screenshot%20(32).png)

Its a medicine reminder app here you can add your medicines and their timings to get notified when its your time to take the medicines.
To run on your local machine, download the repository,install all the dependencies using npm install
then do npm start OR node app.js.
App will run on localhost:8080. 



